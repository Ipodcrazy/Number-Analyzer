// Number Analyzer

// HTML Elements
let numEl = document.getElementById('numInput');

// Add Event Listener
numEl.addEventListener('change', analyzeNumber);

// Event Function
function analyzeNumber() {
    // Get Number from Input Element
    getSign("positive", "negetive", "zero");
    console.log(getSign("positive", "negetive", "zero"));
    // Analyze Number and display results
    document.getElementById('sign').innerHTML = getSign("positive", "negative", "zero");
    document.getElementById('even-odd').innerHTML = evenOrOdd("odd", "even");
    document.getElementById('multiple').innerHTML = multipleOf10("true", "false");
}


// Analyze Functions
function getSign(pos, neg, zero) {
    let numInput = Number(numEl.value);
    if (numInput > 0) {
        return pos;
    }
    else if (numInput < 0) {
        return neg;
    }
    else {
        return zero;
    }
    
}


function evenOrOdd(odd, even) {
    let numInput = Number(numEl.value);
    if (numInput % 2 == 1) {
        return odd;
    }
    numInput = numInput * -1;
    if (numInput % 2 == 1) {
        numInput = numInput * -1;
        return odd;
    }
    if (numInput % 2 == 0) {
        return even;
    }
    numInput = numInput * -1;
    if (numInput % 2 == 0) {
        numInput = numInput * -1;
        return even;
    }
}

function multipleOf10(yes, no) {
    let numInput = Number(numEl.value);
    if (numInput % 10 == 0) {
        return yes;
    }
    else if (numInput % 10 == 1) {
        return no;
    }
    else {
        return no;
    }
}